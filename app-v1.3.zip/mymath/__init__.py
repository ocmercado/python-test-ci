def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(factor1, factor2):
    return factor1 * factor2


def divide(numerator, denominator):
    return float(numerator) / denominator
